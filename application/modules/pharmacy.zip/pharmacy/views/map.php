<!-- Start right Content here -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container">
                    <div class="clearfix">
                        <div class="col-md-12">
                            <h3 class="pull-left page-title">View Map</h3>
                             <a href="<?php echo site_url('pharmacy');?>" class="btn btn-appointment btn-back waves-effect waves-light pull-right"><i class="fa fa-angle-left"></i> Back</a>

                        </div>
                    </div>

                    <!-- Left Section Start -->
                    <section class="col-md-12 detailbox">


                        <!-- Form Section Start -->
                        <article class="row p-b-10">
                          
                        </article>
                        <!-- Form Section End -->

                        <div class="bg-white">
                            <!-- Table Section Start -->
                            <article class="clearfix m-top-40">
                                          <div class="panel panel-default">
                                                
                                                <div class="panel-body">
                      
<!--                                                  <iframe src="https://www.google.com/maps?q=<?php //echo $mapData[0]->ambulance_address;?>&output=embed" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->
                                                    
                                                    	<div id="map" style="width:100%;height:450px;border:0"></div>
                                                </div>
                                            </div>
                        </article>
                        <!-- Table Section End -->
                    
                </div>

                </section>
                <!-- Left Section End -->

            </div>

            <!-- container -->
        </div>
        <!-- content -->
        