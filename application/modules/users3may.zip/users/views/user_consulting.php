 <!-- Start right Content here -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <div class="container">
                    <div class="clearfix">
                        <div class="col-md-12">
                            <h3 class="pull-left page-title">Ambulance Management</h43>

                        </div>
                    </div>

                    <!-- Left Section Start -->
                    <section class="col-md-12 detailbox">


<!--                         Form Section Start 
                        <article class="row p-b-10">
                            <form name="csvDownload" id="" action="<?php //echo site_url('ambulance/createCSV'); ?>" method="post">

                            </form>
                        </article>
                         Form Section End -->

                        <div class="bg-white">
                            <!-- Table Section Start -->
                            <article class="clearfix m-top-40 p-b-20">
                                <aside class="table-responsive">
                                <table class="table all-bloodbank" id="consulting">
                                    <thead>
                                        <tr class="border-a-dull">
                                            <th>Appt Id</th>
                                            <th>Date & Time</th>
                                             <th>MI Name</th>
                                            <th>Doctor</th>
                                            <th>Patient</th>
                                            <th>Appointment Status</th>
                                            <th>Action</th>
                                        </tr>
                                                                          
                                       
                        </thead>
                        </table>
                                    </aside>


                        </article>
                </div>

                </section>
                <!-- Left Section End -->

            </div>

            <!-- container -->
        </div>
